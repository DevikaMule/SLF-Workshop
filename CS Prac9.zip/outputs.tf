output "s3_bucket_name" {
  description = "Name of the lab S3 bucket"
  value       = aws_s3_bucket.lab_bucket.bucket
}

output "security_group_id" {
  description = "Security group identifier"
  value       = aws_security_group.lab_sg.id
}