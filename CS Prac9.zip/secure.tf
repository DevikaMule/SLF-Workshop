
# ==========================================
# SECURE CONFIGURATION - REMEDIATIONS
# ==========================================

# 1. Block public access to S3

resource "aws_s3_bucket_public_access_block" "secure_access" {
  bucket = aws_s3_bucket.lab_bucket.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# 2. Restrict SSH access

resource "aws_security_group" "secure_sg" {
  name        = "terraform-secure-lab-sg"
  description = "Restricted SSH access"

  ingress {
    description = "SSH from approved IP only"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"

    # Example documentation IP range.
    # Replace only with an approved source range
    # if deploying in an authorised environment.
    cidr_blocks = ["203.0.113.10/32"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# 3. Apply least-privilege IAM policy

resource "aws_iam_policy" "secure_policy" {
  name        = "SecureLabPolicy"
  description = "Limited S3 permissions"

  policy = jsonencode({
    Version = "2012-10-17"

    Statement = [{
      Effect = "Allow"

      Action = [
        "s3:ListBucket"
      ]

      Resource = aws_s3_bucket.lab_bucket.arn
    }]
  })
}

# 4. Avoid hard-coded secrets.
# Supply sensitive values through a secure
# secret-management solution or approved
# sensitive input mechanism.
variable "secure_secret" {
  description = "Secret supplied securely"
  type        = string
  sensitive   = true
}
