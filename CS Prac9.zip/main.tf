
# ==========================================
# PRACTICAL 9: TERRAFORM IaC SECURITY REVIEW
# ==========================================

# AWS Provider Configuration
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "ap-south-1"
}

# ==========================================
# RISK 1: PUBLIC S3 BUCKET
# ==========================================

resource "aws_s3_bucket" "lab_bucket" {
  bucket = "terraform-security-lab-example-2026"
}

# Intentionally insecure public access settings
resource "aws_s3_bucket_public_access_block" "lab_public_access" {
  bucket = aws_s3_bucket.lab_bucket.id

  block_public_acls       = false
  block_public_policy     = false
  ignore_public_acls      = false
  restrict_public_buckets = false
}

# ==========================================
# RISK 2: UNRESTRICTED INBOUND TRAFFIC
# ==========================================

resource "aws_security_group" "lab_sg" {
  name        = "terraform-insecure-lab-sg"
  description = "Intentionally insecure security group"

  ingress {
    description = "Allow SSH from anywhere"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# ==========================================
# RISK 3: BROAD IAM PERMISSIONS
# ==========================================

resource "aws_iam_policy" "insecure_policy" {
  name        = "InsecureLabPolicy"
  description = "Intentionally broad IAM policy"

  policy = jsonencode({
    Version = "2012-10-17"

    Statement = [{
      Effect   = "Allow"
      Action   = "*"
      Resource = "*"
    }]
  })
}

# ==========================================
# RISK 4: HARDCODED SECRET
# ==========================================

variable "demo_secret" {
  description = "Illustrative insecure secret"
  type        = string
  default     = "ExamplePassword123"
}

# ==========================================
# END OF INSECURE SAMPLE
# ==========================================
