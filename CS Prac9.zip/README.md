# Practical 9: Terraform IaC Security Review

## Aim
To validate a small Terraform configuration and identify security risks such as public storage, unrestricted ingress, missing encryption, broad IAM permissions and hard-coded secrets without deploying infrastructure.

## 1. Introduction

**Infrastructure as Code (IaC)** is the practice of managing and provisioning infrastructure through machine-readable configuration files rather than manually configuring resources.

**Terraform** is an Infrastructure as Code tool developed by HashiCorp. It allows users to define and manage cloud infrastructure using HashiCorp Configuration Language (HCL).

In this practical, Terraform is used to validate an AWS configuration and identify security misconfigurations. Checkov is optionally used to scan the Terraform files.

## 2. Software Requirements

- Windows 10/11
- Visual Studio Code
- Terraform CLI
- Python (for optional Checkov installation)
- Internet connection for downloading Terraform providers and Checkov

**Note:** AWS deployment is not required. All validation and security scanning can be performed locally.

## 3. Installation and Setup

### Step 1: Install Visual Studio Code

1. Visit https://code.visualstudio.com/
2. Download Visual Studio Code for Windows.
3. Run the installer.
4. Complete the installation.
5. Open Visual Studio Code.

### Step 2: Install Terraform

1. Visit the official Terraform installation page:

   https://developer.hashicorp.com/terraform/install

2. Select Windows as the operating system.
3. Download the Windows AMD64 ZIP package for a typical Intel or AMD laptop.
4. Extract the downloaded ZIP file.
5. Locate `terraform.exe`.
6. Create a folder named `C:\terraform`.
7. Copy `terraform.exe` into this folder.

### Step 3: Configure Environment Variables

1. Open Windows Search.
2. Search for **Edit the system environment variables**.
3. Open the System Properties window.
4. Click **Environment Variables**.
5. Under User variables, select `Path`.
6. Click **Edit** and then **New**.
7. Add:

   `C:\terraform`

8. Click OK to save all changes.
9. Close and reopen PowerShell or the VS Code terminal.

### Step 4: Verify Terraform Installation

Open PowerShell or the VS Code terminal and execute:

```powershell
terraform -version
```

**Expected Output:**

```text
Terraform vX.Y.Z
on windows_amd64
```

The exact version number may differ.

### Step 5: Install Python (Optional)

Python is required only if Checkov is to be installed using pip.

1. Visit https://www.python.org/downloads/
2. Download Python for Windows.
3. Run the installer.
4. Enable the option **Add Python to PATH**.
5. Complete the installation.

Verify the installation:

```powershell
python --version
```

## 4. Project Setup

### Step 1: Create the Project Folder

Create a folder named:

```text
Practical9-Terraform-Security
```

### Step 2: Open the Folder in VS Code

1. Open Visual Studio Code.
2. Select File → Open Folder.
3. Choose `Practical9-Terraform-Security`.
4. Open the integrated terminal using Terminal → New Terminal.

### Step 3: Create the Terraform Files

Create the following files:

```text
Practical9-Terraform-Security/
│
├── main.tf
├── variables.tf
├── outputs.tf
├── secure.tf
└── README.md
```

- `main.tf` – Contains the AWS provider, S3 bucket, insecure security group, broad IAM policy and illustrative hard-coded secret.
- `variables.tf` – Defines Terraform input variables.
- `outputs.tf` – Defines Terraform output values.
- `secure.tf` – Contains examples of security remediations.
- `README.md` – Documents the practical procedure.

Copy the corresponding Terraform code into each file.

**Important:** The initial `main.tf` intentionally contains insecure settings for security review. The `secure.tf` file demonstrates possible remediations. These are review examples, not production-ready infrastructure.

## 5. Terraform Practical Execution

Open the terminal in the project directory.

### Step 1: Initialise Terraform

Execute:

```powershell
terraform init
```

**Purpose:**

- Initialises the Terraform working directory.
- Downloads the required AWS provider.
- Prepares the directory for Terraform operations.

**Expected Output:**

```text
Initializing the backend...

Initializing provider plugins...

Terraform has been successfully initialized!
```

### Step 2: Format Terraform Files

Execute:

```powershell
terraform fmt
```

**Purpose:**

Formats Terraform configuration files into a consistent style by correcting indentation and spacing.

**Expected Output:**

```text
main.tf
secure.tf
```

The filenames displayed depend on which files required formatting.

To verify formatting without changing the files, execute:

```powershell
terraform fmt -check
```

### Step 3: Validate Terraform Configuration

Execute:

```powershell
terraform validate
```

**Purpose:**

Checks Terraform configuration syntax and internal consistency.

**Expected Output:**

```text
Success! The configuration is valid.
```

A successful validation does not guarantee that the configuration is secure. Security misconfigurations can still exist.

### Step 4: Preview Infrastructure Changes (Optional)

Execute this command only in an instructor-approved sandbox:

```powershell
terraform plan
```

**Purpose:**

Displays the infrastructure changes Terraform would perform without applying them.

**Illustrative Output:**

```text
Plan: 3 to add, 0 to change, 0 to destroy.
```

The actual result depends on the configuration and environment.

**Important:** Do not execute `terraform apply`. Infrastructure deployment is not required for this practical.

## 6. Security Risk Identification

Inspect the Terraform files and identify the following security risks.

### Risk 1: Public S3 Bucket

**Insecure Configuration:**

```hcl
block_public_acls       = false
block_public_policy     = false
ignore_public_acls      = false
restrict_public_buckets = false
```

**Problem:**

Public access protections are disabled, which may expose stored objects to unauthorised access.

**Remediation:**

Enable all four public access protection settings:

```hcl
block_public_acls       = true
block_public_policy     = true
ignore_public_acls      = true
restrict_public_buckets = true
```

### Risk 2: Unrestricted Inbound Traffic

**Insecure Configuration:**

```hcl
ingress {
  from_port   = 22
  to_port     = 22
  protocol    = "tcp"
  cidr_blocks = ["0.0.0.0/0"]
}
```

**Problem:**

SSH access is allowed from every IPv4 address.

**Remediation:**

Restrict access to an approved IP range:

```hcl
cidr_blocks = ["203.0.113.10/32"]
```

The above is an illustrative documentation IP address.

### Risk 3: Broad IAM Permissions

**Insecure Configuration:**

```json
{
  "Effect": "Allow",
  "Action": "*",
  "Resource": "*"
}
```

**Problem:**

The policy grants excessive permissions on all resources.

**Remediation:**

Apply the principle of least privilege by granting only the required actions on specific resources.

### Risk 4: Hard-coded Secrets

**Insecure Configuration:**

```hcl
variable "demo_secret" {
  type    = string
  default = "ExamplePassword123"
}
```

**Problem:**

Secrets are stored directly in configuration files and may be exposed through source code repositories.

**Remediation:**

Use secure secret-management systems and avoid storing real credentials in Terraform files.

### Risk 5: Missing Encryption

**Problem:**

Storage resources without explicit encryption configuration may not satisfy the intended security requirements.

**Remediation:**

Configure appropriate encryption at rest, such as Amazon S3 server-side encryption, and use HTTPS/TLS for data in transit.

## 7. Checkov Installation and Security Scanning (Optional)

Checkov is an open-source Infrastructure as Code security scanner that identifies potential security misconfigurations.

### Step 1: Install Checkov

Execute:

```powershell
python -m pip install checkov
```

### Step 2: Verify Installation

Execute:

```powershell
checkov --version
```

### Step 3: Scan the Insecure Terraform File

Execute:

```powershell
checkov -f main.tf
```

Alternatively, scan the complete project directory:

```powershell
checkov -d .
```

### Step 4: Scan the Remediation Examples

Execute:

```powershell
checkov -f secure.tf
```

### Expected Output

Checkov displays security scan results containing:

- Passed checks
- Failed checks
- Skipped checks
- Resource details
- Security recommendations

The insecure configuration is expected to produce security findings. Exact results and finding counts depend on the Checkov version and enabled checks.

## 8. Security Findings and Remediation Table

| Sr. No. | Security Risk | Impact | Recommended Remediation |
|---|---|---|---|
| 1 | Public S3 access | Unauthorised data exposure | Enable Block Public Access |
| 2 | Unrestricted SSH ingress | Unauthorised remote access | Restrict source IP |
| 3 | Broad IAM permissions | Excessive resource access | Follow least privilege |
| 4 | Hard-coded secrets | Credential leakage | Use secure secret management |
| 5 | Missing encryption | Data confidentiality risk | Enable encryption |

## 9. Expected Results

1. Terraform was successfully installed and configured.
2. The working directory was initialised using `terraform init`.
3. Terraform files were formatted using `terraform fmt`.
4. Configuration syntax was checked using `terraform validate`.
5. Security risks were identified in the Terraform configuration.
6. Remediation measures were documented.
7. Checkov was optionally used to scan the Terraform files.
8. No unauthorised infrastructure deployment was performed.

## 10. Screenshots to Attach

Capture the following screenshots for the practical submission:

1. Terraform version displayed in PowerShell.
2. Project folder and Terraform files in VS Code.
3. Successful `terraform init` output.
4. `terraform fmt` output.
5. Successful `terraform validate` output.
6. `terraform plan` output, only if approved and performed.
7. Checkov security scan output, if installed.
8. Security findings and remediation table.

Do not include AWS credentials, Terraform state files or sensitive configuration values in submitted screenshots.

## 11. Conclusion

In this practical, Terraform was used to validate Infrastructure as Code configurations and identify potential security misconfigurations. Security risks such as public S3 access, unrestricted ingress, broad IAM permissions, missing encryption and hard-coded secrets were examined. Appropriate remediation techniques were identified using security best practices. Checkov was optionally used for automated security scanning. The practical was completed without deploying any AWS infrastructure.

## 12. Important Commands – Quick Reference

| Command | Purpose |
|---|---|
| `terraform -version` | Check Terraform installation |
| `terraform init` | Initialise working directory |
| `terraform fmt` | Format Terraform files |
| `terraform fmt -check` | Check formatting |
| `terraform validate` | Validate configuration |
| `terraform plan` | Preview changes (only if approved) |
| `checkov --version` | Check Checkov installation |
| `checkov -f main.tf` | Scan insecure Terraform file |
| `checkov -f secure.tf` | Scan remediation examples |
| `checkov -d .` | Scan project directory |

**Safety Note:** Do not run `terraform apply` or deploy the intentionally insecure configuration. Never submit Terraform state files or AWS credentials.